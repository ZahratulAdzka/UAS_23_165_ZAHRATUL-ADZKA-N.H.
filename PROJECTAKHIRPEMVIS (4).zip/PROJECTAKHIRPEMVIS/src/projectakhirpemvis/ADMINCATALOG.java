/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhirpemvis;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;   
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class ADMINCATALOG extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel modelhijab;
    private DefaultTableModel modelbahan;
    private DefaultTableModel modelkoment;
    private String path = "";
    private byte[] iconBytes;
    int selectedIdd;
    int selectedId;

        
    public ADMINCATALOG () {
        initComponents();
        //public main
        conn = koneksi.getConnection();

        modelhijab = new DefaultTableModel();
        tbl_model.setModel(modelhijab);
        modelhijab.addColumn("ID MODEL");
        modelhijab.addColumn("NAMA MODEL");

        loadDataModel();
        
        
        modelbahan = new DefaultTableModel();
        tbl_bahan.setModel(modelbahan);
        modelbahan.addColumn("ID BAHAN");
        modelbahan.addColumn("NAMA MODEL");
        modelbahan.addColumn("NAMA BAHAN");
        modelbahan.addColumn("DESKRIPSI");
        modelbahan.addColumn("NAMA SUPPLIER");
        
        modelkoment = new DefaultTableModel();
        tbl_koment.setModel(modelkoment);
        modelkoment.addColumn("KOMENTAR");
        modelkoment.addColumn("RATING");
        loadKomentar();

        loadDataBahan();
        loadDataSupplier();
    }
    
    
    
    
private void loadDataModel() {
    modelhijab.setRowCount(0); // Reset model tabel (jika Anda tetap ingin menggunakan tabel)
    cbxmodel.removeAllItems(); // Reset items di JComboBox

    try { 
        String sql = "SELECT * FROM input_model";
        PreparedStatement ps = conn.prepareStatement(sql); // Menyiapkan query
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            // Menambahkan baris ke dalam model tabel (opsional, jika Anda tetap ingin menampilkannya di tabel)
            modelhijab.addRow(new Object[]{
                rs.getInt("id_model"),
                rs.getString("nama_model")
            });

            // Menambahkan item ke JComboBox (gunakan nama model atau ID tergantung kebutuhan)
            cbxmodel.addItem(rs.getString("nama_model")); // Atau gunakan rs.getInt("id_model") jika ingin menambahkan ID
        }
    } catch (SQLException e) {
        System.out.println("Error Load Data: " + e.getMessage());
    }
}




public void loadData() {
    // Clear the existing data in the table
    modelkoment.setRowCount(0);

    try {
        String sql = "SELECT komentar, rating FROM rating";
        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();

        while (rs.next()) {
            // Retrieve each row data
            String komentar = rs.getString("komentar");
            int rating = rs.getInt("rating");

            // Add the row data to the table model
            modelkoment.addRow(new Object[]{komentar, rating});
        }
    } catch (SQLException e) {
        System.out.println("Error Load Data: " + e.getMessage());
    }
}



 private void loadDataBahan() {
    // Clear the existing data in the table model
    modelbahan.setRowCount(0);

    try {
        // SQL query to join input_bahan with input_model and supplier tables
        String sql = "SELECT ib.id_bahan, im.nama_model, ib.nama_bahan, ib.deskripsi, s.nama_supplier " +
                     "FROM input_bahan ib " +
                     "JOIN input_model im ON ib.id_model = im.id_model " +
                     "JOIN supplier s ON ib.id_supplier = s.id_supplier";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        // Process the result set
        while (rs.next()) {

            // Add a new row to the table model
            modelbahan.addRow(new Object[]{
                rs.getInt("id_bahan"),        // ID of the bahan
                rs.getString("nama_model"),    // Name of the model from input_model
                rs.getString("nama_bahan"),    // Name of the bahan
                rs.getString("deskripsi"),     // Description of the bahan
                rs.getString("nama_supplier")  // Name of the supplier from supplier table
            });
        }
    } catch (SQLException e) {
        System.out.println("Error loading data: " + e.getMessage());
    }
}

    
    
    
    
    
        private void loadDataSupplier() {
            cbxsupplier.removeAllItems(); // Hapus semua item di JComboBox sebelum menambahkan yang baru

            try {
                String sql = "SELECT id_supplier, nama_supplier FROM supplier"; // Pastikan kolom sesuai dengan tabel database Anda
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    int idSupplier = rs.getInt("id_supplier"); // Ambil id_supplier
                    String namaSupplier = rs.getString("nama_supplier"); // Ambil nama_supplier

                    // Tambahkan ke JComboBox sebagai ComboBoxItem
                    cbxsupplier.addItem(namaSupplier);
                }
            } catch (SQLException e) {
                System.out.println("Error Load Supplier Data: " + e.getMessage());
            }
        }
        
        
        
private void loadKomentar() {
    // Clear existing data in the table
    modelkoment.setRowCount(0);

    try {
        // Ambil data komentar dan rating dari tabel rating
        String sql = "SELECT komentar, rating FROM rating";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        // Masukkan data ke dalam model tabel
        while (rs.next()) {
            String koment = rs.getString("komentar");
            int rating = rs.getInt("rating");

            // Tambahkan data ke tabel
            modelkoment.addRow(new Object[]{koment, rating});
        }
    } catch (SQLException e) {
        System.out.println("Error loading comments: " + e.getMessage());
    }
}     
        
        
        
        


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        btnratingkeseluruhan = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_koment = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        btn_create_model = new javax.swing.JButton();
        btn_delete_model = new javax.swing.JButton();
        btn_update_model = new javax.swing.JButton();
        btn_exit_model = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_model = new javax.swing.JTable();
        btn_reset_model = new javax.swing.JButton();
        tfmodel = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        tfidmodel = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        btn_create_bahan = new javax.swing.JButton();
        btn_delete_bahan = new javax.swing.JButton();
        btn_update_bahan = new javax.swing.JButton();
        btn_exit_bahan = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        foto = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_bahan = new javax.swing.JTable();
        btn_reset_bahan = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        btnfotobahan = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        txtidbahan = new javax.swing.JTextField();
        txtbahan = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtAdeskripsi = new javax.swing.JTextArea();
        cbxsupplier = new javax.swing.JComboBox<>();
        cbxmodel = new javax.swing.JComboBox<>();
        jLabel24 = new javax.swing.JLabel();
        lbl_poto = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(706, 0, 0, 121));

        jTabbedPane1.setBackground(new java.awt.Color(225, 223, 198));
        jTabbedPane1.setForeground(new java.awt.Color(140, 99, 20));
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        jPanel3.setBackground(new java.awt.Color(225, 223, 198));

        btnratingkeseluruhan.setBackground(new java.awt.Color(255, 228, 228));
        btnratingkeseluruhan.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnratingkeseluruhan.setForeground(new java.awt.Color(103, 68, 15));
        btnratingkeseluruhan.setText("TAMPILKAN RATING");
        btnratingkeseluruhan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnratingkeseluruhanActionPerformed(evt);
            }
        });

        tbl_koment.setBackground(new java.awt.Color(255, 228, 228));
        tbl_koment.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tbl_koment);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnratingkeseluruhan, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnratingkeseluruhan, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(197, 197, 197))
        );

        jTabbedPane1.addTab("NEWS LETTER", jPanel3);

        jPanel5.setBackground(new java.awt.Color(225, 223, 198));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_create_model.setText("CREAT");
        btn_create_model.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_create_modelActionPerformed(evt);
            }
        });
        jPanel5.add(btn_create_model, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, -1, 40));

        btn_delete_model.setText("DELETE");
        btn_delete_model.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_modelActionPerformed(evt);
            }
        });
        jPanel5.add(btn_delete_model, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 140, -1, 40));

        btn_update_model.setText("UPDATE");
        btn_update_model.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_update_modelActionPerformed(evt);
            }
        });
        jPanel5.add(btn_update_model, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 140, -1, 40));

        btn_exit_model.setText("EXIT");
        btn_exit_model.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exit_modelActionPerformed(evt);
            }
        });
        jPanel5.add(btn_exit_model, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 140, 100, 40));

        jLabel11.setBackground(new java.awt.Color(255, 228, 228));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(103, 68, 15));
        jLabel11.setText(" MODEL HIJAB");
        jPanel5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 140, -1));

        jLabel13.setBackground(new java.awt.Color(255, 228, 228));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(103, 68, 15));
        jLabel13.setText("ID MODEL :");
        jPanel5.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 90, -1));

        tbl_model.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_model.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_modelMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_model);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, 510, 300));

        btn_reset_model.setText("RESET");
        btn_reset_model.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_reset_modelActionPerformed(evt);
            }
        });
        jPanel5.add(btn_reset_model, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, -1, 40));
        jPanel5.add(tfmodel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 380, -1));

        jLabel20.setBackground(new java.awt.Color(255, 228, 228));
        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(103, 68, 15));
        jLabel20.setText("NAMA MODEL HIJAB:");
        jPanel5.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 150, -1));
        jPanel5.add(tfidmodel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 380, -1));

        jTabbedPane1.addTab("INPUT MODEL", jPanel5);

        jPanel6.setBackground(new java.awt.Color(225, 223, 198));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_create_bahan.setText("CREAT");
        btn_create_bahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_create_bahanActionPerformed(evt);
            }
        });
        jPanel6.add(btn_create_bahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, -1, 40));

        btn_delete_bahan.setText("DELETE");
        btn_delete_bahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_bahanActionPerformed(evt);
            }
        });
        jPanel6.add(btn_delete_bahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 310, -1, 40));

        btn_update_bahan.setText("UPDATE");
        btn_update_bahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_update_bahanActionPerformed(evt);
            }
        });
        jPanel6.add(btn_update_bahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 310, -1, 40));

        btn_exit_bahan.setText("EXIT");
        btn_exit_bahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exit_bahanActionPerformed(evt);
            }
        });
        jPanel6.add(btn_exit_bahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 310, 100, 40));

        jLabel15.setBackground(new java.awt.Color(255, 228, 228));
        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(103, 68, 15));
        jLabel15.setText("BAHAN HIJAB");
        jPanel6.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 140, -1));

        jLabel18.setBackground(new java.awt.Color(255, 228, 228));
        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(103, 68, 15));
        jLabel18.setText("ID BAHAN :");
        jPanel6.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 90, -1));

        foto.setBackground(new java.awt.Color(255, 228, 228));
        foto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        foto.setForeground(new java.awt.Color(103, 68, 15));
        foto.setText("FOTO :");
        jPanel6.add(foto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 50, -1));

        tbl_bahan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_bahan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_bahanMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_bahan);

        jPanel6.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 510, 180));

        btn_reset_bahan.setText("RESET");
        btn_reset_bahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_reset_bahanActionPerformed(evt);
            }
        });
        jPanel6.add(btn_reset_bahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310, -1, 40));

        jLabel22.setBackground(new java.awt.Color(255, 228, 228));
        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(103, 68, 15));
        jLabel22.setText("NAMA SUPPLIER:");
        jPanel6.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 120, -1));

        btnfotobahan.setBackground(new java.awt.Color(255, 228, 228));
        btnfotobahan.setText("Choose File");
        btnfotobahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfotobahanActionPerformed(evt);
            }
        });
        jPanel6.add(btnfotobahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, -1, 30));

        jLabel23.setBackground(new java.awt.Color(255, 228, 228));
        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(103, 68, 15));
        jLabel23.setText("DESKRIPSI  :");
        jPanel6.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 90, 20));

        jLabel30.setBackground(new java.awt.Color(255, 228, 228));
        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(103, 68, 15));
        jLabel30.setText("NAMA BAHAN:");
        jPanel6.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, -1, -1));
        jPanel6.add(txtidbahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 380, -1));
        jPanel6.add(txtbahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 380, -1));

        txtAdeskripsi.setColumns(20);
        txtAdeskripsi.setRows(5);
        jScrollPane7.setViewportView(txtAdeskripsi);

        jPanel6.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 380, 100));

        jPanel6.add(cbxsupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 380, -1));

        jPanel6.add(cbxmodel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 380, -1));

        jLabel24.setBackground(new java.awt.Color(255, 228, 228));
        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(103, 68, 15));
        jLabel24.setText("NAMA MODEL HIJAB:");
        jPanel6.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 150, -1));
        jPanel6.add(lbl_poto, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 280, 30));

        jTabbedPane1.addTab("INPUT BAHAN", jPanel6);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 690, 550));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 3, 36)); // NOI18N
        jLabel3.setText("CATALOG RIAMIRANDA");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 410, 40));

        jLabel12.setForeground(new java.awt.Color(204, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bguserr1.jpg"))); // NOI18N
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 690, 150));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    
    
    private void btn_create_bahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_create_bahanActionPerformed

 // Validasi input
    if (txtbahan.getText().isEmpty() || txtAdeskripsi.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Pastikan Anda sudah mengisi semua.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Retrieve the ID of the selected model based on nama_model
        String selectedModelName = cbxmodel.getSelectedItem().toString();
        String modelQuery = "SELECT id_model FROM input_model WHERE nama_model = ?";
        PreparedStatement modelStmt = conn.prepareStatement(modelQuery);
        modelStmt.setString(1, selectedModelName);
        ResultSet modelRs = modelStmt.executeQuery();

        int idModel = -1;
        if (modelRs.next()) {
            idModel = modelRs.getInt("id_model");
        }
        modelRs.close();
        modelStmt.close();

        // Retrieve the ID of the selected supplier based on nama_supplier
        String selectedSupplierName = cbxsupplier.getSelectedItem().toString();
        String supplierQuery = "SELECT id_supplier FROM supplier WHERE nama_supplier = ?";
        PreparedStatement supplierStmt = conn.prepareStatement(supplierQuery);
        supplierStmt.setString(1, selectedSupplierName);
        ResultSet supplierRs = supplierStmt.executeQuery();

        int idSupplier = -1;
        if (supplierRs.next()) {
            idSupplier = supplierRs.getInt("id_supplier");
        }
        supplierRs.close();
        supplierStmt.close();

        // Check if both IDs were found
        if (idModel == -1 || idSupplier == -1) {
            JOptionPane.showMessageDialog(this, "Model atau Supplier tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert data into input_bahan table
        String sql = "INSERT INTO input_bahan (id_model, nama_bahan, deskripsi, foto, id_supplier) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);

        // Set values for the prepared statement
        ps.setInt(1, idModel);                  // Set id_model
        ps.setString(2, txtbahan.getText());     // Set nama_bahan
        ps.setString(3, txtAdeskripsi.getText()); // Set deskripsi

        // Set foto as byte array if iconBytes is not null, otherwise set it to NULL
        if (iconBytes == null) {
            JOptionPane.showMessageDialog(this, "Pastikan Anda sudah mengunggah file.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            ps.setBytes(4, iconBytes);  // Set foto
        }
        ps.setInt(5, idSupplier);               // Set id_supplier

        // Execute the statement to save data in the database
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Data berhasil disimpan");
    } catch (SQLException e) {
        System.out.println("Error Save Data: " + e.getMessage());
    }
    loadDataBahan();
    }//GEN-LAST:event_btn_create_bahanActionPerformed

    private void btn_delete_bahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_bahanActionPerformed
// TODO add your handling code here:
        try {
            // Eksekusi perintah DELETE
            String sql = "DELETE FROM input_bahan WHERE id_bahan = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1,selectedIdd);
            int rowsDeleted = ps.executeUpdate();

            // Cek jika data berhasil dihapus
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus");
                loadDataBahan();
            } else {
                JOptionPane.showMessageDialog(this, "ID bahan tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID bahan tidak valid.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btn_delete_bahanActionPerformed

    private void btn_update_bahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_update_bahanActionPerformed
           // Validasi input
    if (txtidbahan.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "ID bahan belum diisi.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (txtbahan.getText().isEmpty() || txtAdeskripsi.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Pastikan Anda sudah mengisi semua.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {

        // Retrieve the ID of the selected model based on nama_model
        String selectedModelName = cbxmodel.getSelectedItem().toString();
        String modelQuery = "SELECT id_model FROM input_model WHERE nama_model = ?";
        PreparedStatement modelStmt = conn.prepareStatement(modelQuery);
        modelStmt.setString(1, selectedModelName);
        ResultSet modelRs = modelStmt.executeQuery();

        int idModel = -1;
        if (modelRs.next()) {
            idModel = modelRs.getInt("id_model");
        }
        modelRs.close();
        modelStmt.close();

        // Retrieve the ID of the selected supplier based on nama_supplier
        String selectedSupplierName = cbxsupplier.getSelectedItem().toString();
        String supplierQuery = "SELECT id_supplier FROM supplier WHERE nama_supplier = ?";
        PreparedStatement supplierStmt = conn.prepareStatement(supplierQuery);
        supplierStmt.setString(1, selectedSupplierName);
        ResultSet supplierRs = supplierStmt.executeQuery();

        int idSupplier = -1;
        if (supplierRs.next()) {
            idSupplier = supplierRs.getInt("id_supplier");
        }
        supplierRs.close();
        supplierStmt.close();

        // Check if both IDs were found
        if (idModel == -1 || idSupplier == -1) {
            JOptionPane.showMessageDialog(this, "Model atau Supplier tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Update data in input_bahan table
        String sql = "UPDATE input_bahan SET id_model = ?, nama_bahan = ?, deskripsi = ?, foto = ?, id_supplier = ? WHERE id_bahan = ?";
        PreparedStatement ps = conn.prepareStatement(sql);

        // Set values for the prepared statement
        ps.setInt(1, idModel);                      // Set id_model
        ps.setString(2, txtbahan.getText());         // Set nama_bahan
        ps.setString(3, txtAdeskripsi.getText());    // Set deskripsi

        // Set foto as byte array if iconBytes is not null, otherwise set it to NULL
        if (iconBytes == null) {
            JOptionPane.showMessageDialog(this, "Pastikan Anda sudah mengunggah file.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            ps.setBytes(4, iconBytes);  // Set foto
        }
        ps.setInt(5, idSupplier);               // Set id_supplier
        ps.setInt(6, selectedIdd);                  // Set id_bahan for the WHERE clause

        // Execute the statement to update data in the database
        int rowsUpdated = ps.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Data berhasil diupdate");
        } else {
            JOptionPane.showMessageDialog(this, "ID bahan tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        System.out.println("Error Update Data: " + e.getMessage());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "ID bahan tidak valid.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    loadDataBahan();
    }//GEN-LAST:event_btn_update_bahanActionPerformed

    private void btn_exit_bahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exit_bahanActionPerformed
    // Menampilkan dialog konfirmasi sebelum keluar dari aplikasi
    int confirm = JOptionPane.showConfirmDialog(this, 
                   "Apakah Anda yakin ingin keluar?", 
                   "Konfirmasi Keluar", 
                   JOptionPane.YES_NO_OPTION, 
                   JOptionPane.QUESTION_MESSAGE);
    
    // Jika pengguna memilih "Yes", aplikasi akan ditutup
    if (confirm == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_btn_exit_bahanActionPerformed

    private void btn_reset_bahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_reset_bahanActionPerformed
        // Mengosongkan semua field input bahan
        txtidbahan.setText("");
        cbxmodel.setSelectedIndex(0); // Reset combo box ke pilihan pertama
        txtAdeskripsi.setText("");
        cbxsupplier.setSelectedIndex(0); // Reset combo box ke pilihan pertama

        // Tampilkan pesan konfirmasi reset
        JOptionPane.showMessageDialog(this, "Form berhasil direset");
    }//GEN-LAST:event_btn_reset_bahanActionPerformed

    private void btnfotobahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfotobahanActionPerformed
    JFileChooser choser = new JFileChooser();
            int result = choser.showOpenDialog(null);

            if (result == JFileChooser.APPROVE_OPTION) {
                File f = choser.getSelectedFile();
                String path = f.getAbsolutePath();
                String fileName = f.getName();

                try {
                    BufferedImage bi = ImageIO.read(new File(path));
                    Image img = bi.getScaledInstance(650, 360, Image.SCALE_SMOOTH);
                    ImageIcon icon = new ImageIcon(img);
                    lbl_poto.setText(fileName);
                    JOptionPane.showMessageDialog(null, "Upload berhasil!", "Sukses", JOptionPane.INFORMATION_MESSAGE);

                    // Baca gambar sebagai byte array untuk disimpan ke database
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ImageIO.write(bi, "png", baos);
                    iconBytes = baos.toByteArray();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Gagal mengunggah gambar!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Upload dibatalkan!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            }        // TODO add your handling code here:
    }//GEN-LAST:event_btnfotobahanActionPerformed

    
    
    
    
    
    
    
    
    
    
    
    
    
    private void btn_reset_modelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_reset_modelActionPerformed
        // Mengosongkan semua field input model
        tfidmodel.setText("");
        tfmodel.setText("");

        // Tambahkan reset untuk komponen lain jika diperlukan, misalnya:
        // cbxCategory.setSelectedIndex(0); // Untuk mengatur ulang combo box ke pilihan pertama
        // modelTable.clearSelection();     // Untuk menghapus seleksi pada tabel, jika ada

        JOptionPane.showMessageDialog(this, "Form berhasil direset");
    }//GEN-LAST:event_btn_reset_modelActionPerformed

    private void btn_exit_modelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exit_modelActionPerformed
    // Menampilkan dialog konfirmasi sebelum keluar dari aplikasi
    int confirm = JOptionPane.showConfirmDialog(this, 
                   "Apakah Anda yakin ingin keluar?", 
                   "Konfirmasi Keluar", 
                   JOptionPane.YES_NO_OPTION, 
                   JOptionPane.QUESTION_MESSAGE);
    
    // Jika pengguna memilih "Yes", aplikasi akan ditutup
    if (confirm == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_btn_exit_modelActionPerformed

    private void btn_update_modelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_update_modelActionPerformed
        // Validasi input
        if (tfidmodel.getText().isEmpty() || tfmodel.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pastikan Anda sudah mengisi semua data.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Keluar dari metode jika input tidak valid
        }

        try {
            // SQL untuk memperbarui nama model berdasarkan id_model
            String sql = "UPDATE input_model SET nama_model = ? WHERE id_model = ?";
            PreparedStatement ps = conn.prepareStatement(sql);

            // Ambil nilai dari JTextField dan masukkan ke PreparedStatement
            ps.setString(1, tfmodel.getText()); // Set nama_model
            ps.setInt(2, Integer.parseInt(tfidmodel.getText())); // Set id_model

            // Eksekusi perintah update dan cek jika ada data yang diperbarui
            int rowsUpdated = ps.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil diperbarui.");
            } else {
                JOptionPane.showMessageDialog(this, "ID model tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat memperbarui data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error Update Data: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID model tidak valid.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Muat ulang data setelah pembaruan untuk memperbarui tampilan
        loadDataModel();
    }//GEN-LAST:event_btn_update_modelActionPerformed

    private void btn_delete_modelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_modelActionPerformed
        // Validasi input
        

        try {
            // Tampilkan dialog konfirmasi sebelum menghapus data
            int confirm = JOptionPane.showConfirmDialog(this, 
                        "Apakah Anda yakin ingin menghapus data ini?", 
                        "Konfirmasi Hapus", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.QUESTION_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                String sql = "DELETE FROM input_model WHERE id_model = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1,selectedId);

                int rowsDeleted = ps.executeUpdate();
                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(this, "Data berhasil dihapus");
                } else {
                    JOptionPane.showMessageDialog(this, "ID model tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menghapus data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error Delete Data: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID model tidak valid.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Muat ulang data setelah penghapusan untuk memperbarui tampilan
        loadDataModel();
    }//GEN-LAST:event_btn_delete_modelActionPerformed

    private void btn_create_modelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_create_modelActionPerformed
        // Validasi input
        if (tfmodel.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pastikan Anda sudah mengisi semua data.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Keluar dari metode jika input tidak valid
        }

        try {
            // SQL untuk menambahkan model baru
            String sql = "INSERT INTO input_model (nama_model) VALUES (?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            // Ambil nilai dari JTextField dan masukkan ke PreparedStatement
            String namaModel = tfmodel.getText();
            ps.setString(1, namaModel);

            // Eksekusi perintah untuk menyimpan data ke database
            ps.executeUpdate();

            // Tampilkan pesan sukses dan kosongkan field setelah penyimpanan berhasil
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan.");
            tfmodel.setText(""); // Mengosongkan field input setelah penyimpanan
        } catch (SQLException e) {
            // Tampilkan pesan error yang lebih informatif
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error Save Data: " + e.getMessage());
        }

        // Muat ulang data setelah penyimpanan untuk memperbarui tampilan
        loadDataModel();
    }//GEN-LAST:event_btn_create_modelActionPerformed

    
    
    
    
    
    
    
    
    
    
    
    
    private void btnratingkeseluruhanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnratingkeseluruhanActionPerformed
            try {
        // Query untuk mengambil semua rating dari tabel rating
        String sql = "SELECT rating FROM rating";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        int totalRating = 0;
        int count = 0;
        
        // Proses untuk menjumlahkan semua rating
        while (rs.next()) {
            totalRating += rs.getInt("rating");  // Menambahkan rating ke total
            count++;  // Menghitung jumlah rating
        }
        
        // Menghitung rata-rata
        double averageRating = (count > 0) ? (double) totalRating / count : 0.0;
        
        // Menampilkan rata-rata di JOptionPane
        JOptionPane.showMessageDialog(this, 
            "Rata-rata Rating Keseluruhan: " + String.format("%.2f", averageRating), 
            "Rata-rata Rating", 
            JOptionPane.INFORMATION_MESSAGE);
        
    } catch (SQLException e) {
        System.out.println("Error calculating average rating: " + e.getMessage());
        JOptionPane.showMessageDialog(this, 
            "Terjadi kesalahan saat menghitung rata-rata rating", 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnratingkeseluruhanActionPerformed

    private void tbl_bahanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_bahanMouseClicked
        int selectedrow = tbl_bahan.getSelectedRow();
        // Ambil ID yang dipilih
        selectedIdd = Integer.parseInt(tbl_bahan.getValueAt(selectedrow, 0).toString()); 
  
    }//GEN-LAST:event_tbl_bahanMouseClicked

    private void tbl_modelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_modelMouseClicked
        // TODO add your handling code here:
        int selectedrow = tbl_model.getSelectedRow();
        // Ambil ID yang dipilih
        selectedId = Integer.parseInt(tbl_model.getValueAt( selectedrow, 0).toString()); 
  
    }//GEN-LAST:event_tbl_modelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ADMINCATALOG().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_create_bahan;
    private javax.swing.JButton btn_create_model;
    private javax.swing.JButton btn_delete_bahan;
    private javax.swing.JButton btn_delete_model;
    private javax.swing.JButton btn_exit_bahan;
    private javax.swing.JButton btn_exit_model;
    private javax.swing.JButton btn_reset_bahan;
    private javax.swing.JButton btn_reset_model;
    private javax.swing.JButton btn_update_bahan;
    private javax.swing.JButton btn_update_model;
    private javax.swing.JButton btnfotobahan;
    private javax.swing.JButton btnratingkeseluruhan;
    private javax.swing.JComboBox<String> cbxmodel;
    private javax.swing.JComboBox<String> cbxsupplier;
    private javax.swing.JLabel foto;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbl_poto;
    private javax.swing.JTable tbl_bahan;
    private javax.swing.JTable tbl_koment;
    private javax.swing.JTable tbl_model;
    private javax.swing.JTextField tfidmodel;
    private javax.swing.JTextField tfmodel;
    private javax.swing.JTextArea txtAdeskripsi;
    private javax.swing.JTextField txtbahan;
    private javax.swing.JTextField txtidbahan;
    // End of variables declaration//GEN-END:variables
}
