/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhirpemvis;

import com.mysql.cj.jdbc.Blob;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author SMK_BIM
 */
public class USERCATALOG extends javax.swing.JFrame {
 Connection conn = koneksi.getConnection();
    /**
     * Creates new form CustomHijab
     */
    public USERCATALOG () {
        initComponents();
       data();

    }
    

    
    
    
    
    
    
private void data() {
    // Query untuk mengambil model dan nama model (bergabung dengan tabel model)
    String querymodel = "SELECT DISTINCT m.id_model, m.nama_model FROM input_model m " +
                        "LEFT JOIN input_bahan ib ON m.id_model = ib.id_model";

    // Query untuk mengambil bahan berdasarkan model yang dipilih (bergabung dengan tabel bahan)
    String querybahan = "SELECT b.id_bahan, b.nama_bahan FROM input_bahan ib " +
                        "JOIN input_bahan b ON ib.id_bahan = b.id_bahan WHERE ib.id_model = ?";

    // Kosongkan combo box model sebelum mengisinya
    cbxmodel.removeAllItems();
    
    try (PreparedStatement psmodel = conn.prepareStatement(querymodel);
         ResultSet rsmodel = psmodel.executeQuery()) {

        // Mengisi combo box model dengan nama model
        while (rsmodel.next()) {
            String namamodel = rsmodel.getString("nama_model");  // Ambil nama model
            cbxmodel.addItem(namamodel);
        }
    } catch (SQLException e) {
        System.out.println("Error loading models: " + e.getMessage());
    }

    // Tambahkan listener untuk combo box model, agar saat model dipilih, bahan bisa dimuat
    cbxmodel.addActionListener(e -> {
        String selectedModelName = (String) cbxmodel.getSelectedItem();
        if (selectedModelName != null) {
            // Ambil id_model dari nama_model yang dipilih
            String selectedModelId = getModelIdByName(selectedModelName);
            if (selectedModelId != null) {
                loadbahan(selectedModelId, querybahan);
            }
        }
    });
}

private String getModelIdByName(String modelName) {
    // Query untuk mendapatkan id_model berdasarkan nama_model
    String query = "SELECT id_model FROM input_model WHERE nama_model = ?";
    try (PreparedStatement ps = conn.prepareStatement(query)) {
        ps.setString(1, modelName);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getString("id_model"); // Mengambil id_model dari hasil query
        }
    } catch (SQLException e) {
        System.out.println("Error getting model id: " + e.getMessage());
    }
    return null;
}

private void loadbahan(String modelId, String querybahan) {
    cbxbahan.removeAllItems();  // Kosongkan combo box bahan sebelum memuat data baru

    try (PreparedStatement psbahan = conn.prepareStatement(querybahan)) {
        // Set parameter id_model yang dipilih
        psbahan.setString(1, modelId);
        ResultSet rsbahan = psbahan.executeQuery();

        // Mengisi combo box bahan dengan nama bahan
        while (rsbahan.next()) {
            String namaBahan = rsbahan.getString("nama_bahan");  // Ambil nama bahan
            cbxbahan.addItem(namaBahan);
        }
    } catch (SQLException e) {
        System.out.println("Error loading bahan: " + e.getMessage());
    }
}



    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea6 = new javax.swing.JTextArea();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextArea7 = new javax.swing.JTextArea();
        jLabel17 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btnexit = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        btnkembali = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        btn_kirim = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_koment = new javax.swing.JTextArea();
        spn_rating = new javax.swing.JSpinner();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_deskripsi = new javax.swing.JTextArea();
        btnkeluar = new javax.swing.JButton();
        lbl_gambar = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        cbxmodel = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        cbxbahan = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        btn_tampilkan = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel10.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(706, 0, 0, 121));

        jTabbedPane1.setBackground(new java.awt.Color(225, 223, 198));
        jTabbedPane1.setForeground(new java.awt.Color(140, 99, 20));
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        jPanel2.setBackground(new java.awt.Color(225, 223, 198));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setBackground(new java.awt.Color(255, 228, 228));
        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(103, 68, 15));
        jLabel18.setText("ABOUT US");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 220, -1));

        jLabel15.setBackground(new java.awt.Color(255, 228, 228));
        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(103, 68, 15));
        jLabel15.setText("INFORMATION ");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 180, -1));
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setLayout(null);

        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jTextArea4.setForeground(new java.awt.Color(103, 68, 15));
        jTextArea4.setRows(5);
        jTextArea4.setText("Ria Miranda, \n sebagai Direktur Kreatif,memulai perjalanannya didunia mode setelah  lulus \ndari sekolah mode ESMOD di Jakarta.\nInspirasi kami berasal dari  keindahan alam Indonesia yang menakjubkan. \nSetiap kreasi menghormati lanskap, warna, dan tekstur yang menjadi ciri khas \nnegeri ini.  \n\n RiaMiranda bukan hanya sekadar mode ini adalah  perpaduan nilai, keindahan, \ndan semangat luar biasa Indonesia.  Nikmati dalam perjalanan ini bersama\n koleksi kami. Setiap produk membawa cerita dan nilai kehidupan, \ndengan desain  yang meningkatkan kenyamanan sehari-hari.   \nRiaMiranda berdiri di atas dua pilar utama: RMLC (komunitas setia)\ndan melayani muslimah yang mencakup seluruh Indonesia");
        jScrollPane4.setViewportView(jTextArea4);

        jPanel8.add(jScrollPane4);
        jScrollPane4.setBounds(0, 0, 460, 220);

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 460, 220));

        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextArea3.setForeground(new java.awt.Color(103, 68, 15));
        jTextArea3.setRows(5);
        jTextArea3.setText(" Berdasarkan dasar kami, ada dua pilar utama: \n 1. RMLC (RiaMiranda Loyal Community): sebagai pelopor dalam mengelola komunitas\n yang merayakan hubungan yang langgeng dengan pelanggan kami, sebagai bukti \nhubungan yang telah kami bangun dengan lebih dari 120.000 orang yang berbagi\n filosofi merek kami. \n 2. Jaringan Toko: Kehadiran kami mencakup provinsi-provinsi di Indonesia, \ndengan jaringan 45 toko dan terus berkembang di masa depan yang juga mencakup\n toko-toko di department store dan mitra e-commerce. ");
        jScrollPane3.setViewportView(jTextArea3);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 410, 480, 170));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 530, 200));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel2.setText("jLabel1");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 530, 280));

        jPanel4.setBackground(new java.awt.Color(225, 223, 198));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setBackground(new java.awt.Color(255, 228, 228));
        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(103, 68, 15));
        jLabel20.setText("ABOUT US");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 220, -1));

        jLabel16.setBackground(new java.awt.Color(255, 228, 228));
        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(103, 68, 15));
        jLabel16.setText("INFORMATION ");
        jPanel4.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 180, -1));

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setLayout(null);

        jTextArea6.setColumns(20);
        jTextArea6.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jTextArea6.setForeground(new java.awt.Color(103, 68, 15));
        jTextArea6.setRows(5);
        jTextArea6.setText("Ria Miranda, \n sebagai Direktur Kreatif,memulai perjalanannya didunia mode setelah  lulus \ndari sekolah mode ESMOD di Jakarta.\nInspirasi kami berasal dari  keindahan alam Indonesia yang menakjubkan. \nSetiap kreasi menghormati lanskap, warna, dan tekstur yang menjadi ciri khas \nnegeri ini.  \n\n RiaMiranda bukan hanya sekadar mode ini adalah  perpaduan nilai, keindahan, \ndan semangat luar biasa Indonesia.  Nikmati dalam perjalanan ini bersama\n koleksi kami. Setiap produk membawa cerita dan nilai kehidupan, \ndengan desain  yang meningkatkan kenyamanan sehari-hari.   \nRiaMiranda berdiri di atas dua pilar utama: RMLC (komunitas setia)\ndan melayani muslimah yang mencakup seluruh Indonesia");
        jScrollPane6.setViewportView(jTextArea6);

        jPanel12.add(jScrollPane6);
        jScrollPane6.setBounds(0, 0, 460, 220);

        jPanel4.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 460, 220));

        jTextArea7.setColumns(20);
        jTextArea7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextArea7.setForeground(new java.awt.Color(103, 68, 15));
        jTextArea7.setRows(5);
        jScrollPane7.setViewportView(jTextArea7);

        jPanel4.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, 480, 170));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel17.setText("jLabel1");
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 530, 200));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel22.setText("jLabel1");
        jPanel4.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 530, 280));

        btnexit.setBackground(new java.awt.Color(103, 68, 15));
        btnexit.setForeground(new java.awt.Color(255, 228, 228));
        btnexit.setText("KELUAR");
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });
        jPanel4.add(btnexit, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, -1, -1));

        jLabel19.setBackground(new java.awt.Color(255, 228, 228));
        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(103, 68, 15));
        jLabel19.setText("COMPANY VALUE");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 220, -1));

        btnkembali.setBackground(new java.awt.Color(103, 68, 15));
        btnkembali.setForeground(new java.awt.Color(255, 228, 228));
        btnkembali.setText("KEMBALI");
        btnkembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkembaliActionPerformed(evt);
            }
        });
        jPanel4.add(btnkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 50, -1, -1));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("HOME", jPanel2);

        jPanel3.setBackground(new java.awt.Color(225, 223, 198));
        jPanel3.setLayout(null);

        jTextArea5.setColumns(20);
        jTextArea5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextArea5.setForeground(new java.awt.Color(103, 68, 15));
        jTextArea5.setRows(5);
        jTextArea5.setText("KAMI MENYAMBUT PERTANYAAN, SARAN, PUJIAN, DAN KELUHAN \nANDA UNTUK MENINGKATKAN LAYANAN KAMI.  \n\nCara tercepat untuk menemukan apa yang Anda cari adalah melalui\n halaman Layanan Pelanggan & FAQ Belanja kami. Jika Anda masih belum yakin, kami menawarkan \nkesempatan jendela komentar catalog . \n\n Untuk informasi lebih lanjut, hubungi CS RiaMiranda Official. ");
        jScrollPane5.setViewportView(jTextArea5);

        jPanel3.add(jScrollPane5);
        jScrollPane5.setBounds(50, 70, 490, 300);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel13.setText("jLabel1");
        jPanel3.add(jLabel13);
        jLabel13.setBounds(30, 40, 530, 360);

        btn_kirim.setText("Kirim");
        btn_kirim.setToolTipText("");
        btn_kirim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kirimActionPerformed(evt);
            }
        });
        jPanel3.add(btn_kirim);
        btn_kirim.setBounds(140, 540, 320, 50);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bgfashion1.jpg"))); // NOI18N
        jLabel11.setText("jLabel1");
        jPanel3.add(jLabel11);
        jLabel11.setBounds(120, 530, 360, 70);

        jLabel23.setBackground(new java.awt.Color(255, 228, 228));
        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(103, 68, 15));
        jLabel23.setText("LAYANAN PENGUNJUNG");
        jPanel3.add(jLabel23);
        jLabel23.setBounds(170, 10, 215, 25);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(103, 68, 15));
        jLabel24.setText("COMMENT :");
        jPanel3.add(jLabel24);
        jLabel24.setBounds(40, 410, 80, 20);

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(103, 68, 15));
        jLabel25.setText("GIVE US RATING :");
        jPanel3.add(jLabel25);
        jLabel25.setBounds(10, 500, 120, 20);

        txt_koment.setColumns(20);
        txt_koment.setRows(5);
        jScrollPane2.setViewportView(txt_koment);

        jPanel3.add(jScrollPane2);
        jScrollPane2.setBounds(130, 410, 440, 86);

        spn_rating.setModel(new javax.swing.SpinnerNumberModel(1, 1, 5, 1));
        jPanel3.add(spn_rating);
        spn_rating.setBounds(130, 500, 64, 22);

        jTabbedPane1.addTab("COMMENT ", jPanel3);

        jPanel5.setBackground(new java.awt.Color(225, 223, 198));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setBackground(new java.awt.Color(255, 228, 228));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(103, 68, 15));
        jLabel5.setText("MODEL");
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 230, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(103, 68, 15));
        jLabel8.setText("DESKRIPSI");
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, -1, -1));

        txt_deskripsi.setColumns(20);
        txt_deskripsi.setRows(5);
        jScrollPane1.setViewportView(txt_deskripsi);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 280, 260, 320));

        btnkeluar.setBackground(new java.awt.Color(103, 68, 15));
        btnkeluar.setForeground(new java.awt.Color(255, 228, 228));
        btnkeluar.setText("KELUAR");
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });
        jPanel5.add(btnkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, -1, -1));

        lbl_gambar.setText("FOTO");
        lbl_gambar.setPreferredSize(new java.awt.Dimension(258, 307));
        jPanel5.add(lbl_gambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 260, 310));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cbxmodel, 0, 380, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cbxmodel, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel5.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 380, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(103, 68, 15));
        jLabel6.setText("MODEL HIJAB");
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cbxbahan, 0, 380, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cbxbahan)
        );

        jPanel5.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 380, 40));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(103, 68, 15));
        jLabel9.setText("BAHAN");
        jPanel5.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        btn_tampilkan.setBackground(new java.awt.Color(103, 68, 15));
        btn_tampilkan.setForeground(new java.awt.Color(255, 228, 228));
        btn_tampilkan.setText("TAMPILKAN");
        btn_tampilkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tampilkanActionPerformed(evt);
            }
        });
        jPanel5.add(btn_tampilkan, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 135, 40));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(103, 68, 15));
        jLabel21.setText("GAMBAR");
        jPanel5.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, -1, -1));

        jTabbedPane1.addTab("COLLECTION", jPanel5);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 680, 610));

        jPanel10.setBackground(new java.awt.Color(235, 220, 199));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 3, 36)); // NOI18N
        jLabel3.setText("CATALOG RIAMIRANDA");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, -1, 50));

        jLabel12.setBackground(new java.awt.Color(255, 153, 255));
        jLabel12.setForeground(new java.awt.Color(204, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectakhirpemvis/bguserr1.jpg"))); // NOI18N
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 690, 120));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_tampilkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tampilkanActionPerformed
    // Ambil bahan yang dipilih dari combo box cbxbahan
       String selectedBahan = (String) cbxbahan.getSelectedItem();

       if (selectedBahan != null) {
           // Cari id_bahan berdasarkan nama bahan yang dipilih
           String query = "SELECT b.id_bahan, b.nama_bahan, b.deskripsi, b.foto, s.nama_supplier " +
                       "FROM input_bahan b " +
                       "JOIN supplier s ON b.id_supplier = s.id_supplier " +
                       "WHERE b.nama_bahan = ?";

           try (PreparedStatement ps = conn.prepareStatement(query)) {
               // Set parameter nama bahan yang dipilih
               ps.setString(1, selectedBahan);

               // Eksekusi query untuk mendapatkan deskripsi dan foto
               ResultSet rs = ps.executeQuery();

               if (rs.next()) {
                   // Ambil deskripsi dan foto dari hasil query
                   String deskripsi = rs.getString("deskripsi");
                   String namaSuplier = rs.getString("nama_supplier");
                   Blob fotoBlob = (Blob) rs.getBlob("foto");

                   // Tampilkan deskripsi di txt_deskripsi
                   txt_deskripsi.setText(deskripsi+"\n"+"Dari Supplier"+namaSuplier);

                   // Tampilkan gambar di lbl_gambar
                   if (fotoBlob != null) {
                       // Mengambil gambar dari BLOB
                       InputStream inputStream = fotoBlob.getBinaryStream();
                       BufferedImage image = ImageIO.read(inputStream);
                       ImageIcon imageIcon = new ImageIcon(image);

                       // Mengatur ukuran gambar agar sesuai dengan prefered size
                       Image img = imageIcon.getImage();
                       Image scaledImg = img.getScaledInstance(258, 307, Image.SCALE_SMOOTH);
                       lbl_gambar.setIcon(new ImageIcon(scaledImg));
                   } else {
                       // Jika foto kosong, set icon default atau kosongkan label
                       lbl_gambar.setIcon(null);
                   }
               }
           } catch (SQLException | IOException e) {
               System.out.println("Error loading bahan details: " + e.getMessage());
           }
       }
    }//GEN-LAST:event_btn_tampilkanActionPerformed

    private void btn_kirimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kirimActionPerformed
        String koment = txt_koment.getText();
        int value = (Integer) spn_rating.getValue();

        // Validasi jika komentar kosong
        if (koment.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Komentar tidak boleh kosong", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return; // Keluar dari metode agar tidak lanjut ke proses penyimpanan
        }

        try {
            String sql = "INSERT INTO rating (komentar, rating) VALUES (?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, koment);
            ps.setInt(2, value);

            ps.executeUpdate(); // Menyimpan data ke database
            JOptionPane.showMessageDialog(this, "Data saved successfully");
        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_kirimActionPerformed

    private void btnkembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkembaliActionPerformed
        // TODO add your handling code here:
         new Welcomee().setVisible(true);
    }//GEN-LAST:event_btnkembaliActionPerformed

    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
       
        int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnexitActionPerformed

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
    // Menampilkan konfirmasi untuk keluar aplikasi
    int confirm = JOptionPane.showConfirmDialog(this, 
        "Apakah Anda yakin ingin keluar?", 
        "Konfirmasi Keluar", 
        JOptionPane.YES_NO_OPTION);
    
    // Jika pengguna memilih "Yes", keluar aplikasi
    if (confirm == JOptionPane.YES_OPTION) {
        System.exit(0);  // Atau bisa menggunakan this.dispose() jika ingin hanya menutup frame
    }
    }//GEN-LAST:event_btnkeluarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new USERCATALOG().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_kirim;
    private javax.swing.JButton btn_tampilkan;
    private javax.swing.JButton btnexit;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnkembali;
    private javax.swing.JComboBox<String> cbxbahan;
    private javax.swing.JComboBox<String> cbxmodel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextArea jTextArea6;
    private javax.swing.JTextArea jTextArea7;
    private javax.swing.JLabel lbl_gambar;
    private javax.swing.JSpinner spn_rating;
    private javax.swing.JTextArea txt_deskripsi;
    private javax.swing.JTextArea txt_koment;
    // End of variables declaration//GEN-END:variables
}
